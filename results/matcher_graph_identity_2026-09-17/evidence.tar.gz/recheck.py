"""Re-extract every artifact with v2; reuse prior pairs only for identical inputs.
Original baseline binaries/source hashes/pairs were verified in the first audit.
"""
from concurrent.futures import ProcessPoolExecutor, as_completed
import json
from pathlib import Path
import subprocess
import sys
import tempfile

sys.path.insert(0,'/home/yunzez/c2rust_testing/scripts')
import rq1_graph_identity_audit as a

BASE=Path(__file__).parent
NEW=BASE/'analyzer_v2/target/release/analyzer'

def run(job):
    group, case, refdir, outdir=job
    ref=Path(refdir)/f'{group}__{case}'
    dest=Path(outdir)/f'{group}__{case}'
    dest.mkdir()
    row=a.read(ref/'comparison.json')
    assert row['source_hash_matches_archive'] and row['old_pairs_match_archive']
    old=a.read(ref/'old.rust.json')
    prior=a.read(ref/'new.rust.json')
    raw=a.ARCHIVE/'raw'/f'group_{group}'/case
    c=a.read(raw/'c_analyzer.json')
    if group=='a':
        lib,tool=case.split('__'); cfg=a.group_a.RUST[lib,tool]
        truth={k:v.rsplit('::',1)[-1] for k,v in a.read(raw/'truth.json')['truth'].items()}
        fingerprint=a.read(a.ARCHIVE/'rows/group_a_full.json')[case]['fingerprint']
        assert a.group_a.tree_hash(a.group_a.rust_files(cfg))==fingerprint['rust_artifact_sha256']
    else:
        cfg=a.group_b.CASES[case]
        sheet=a.read(a.ARCHIVE/'annotation'/case/'sheet.json')
        truth={r['c_function']:r['truth'] for r in sheet['rows'] if r['truth'] not in ('','NONE','AMBIGUOUS')
               and not r['truth'].startswith(('STUB:','SPLIT:','MERGED:'))}
        paths=[cfg['crate']] if Path(cfg['crate']).is_file() else a.group_b.rust_files(cfg['crate'])
        assert a.group_b.tree_hash(paths)==sheet['fingerprint']['rust_artifact_sha256']
    with tempfile.TemporaryDirectory(prefix='stage-',dir=dest) as stage:
        crate=a.group_a.stage_crate(cfg,lib,stage)[0] if group=='a' else a.group_b.stage_crate(cfg,stage)
        proc=subprocess.run([str(NEW),crate,'--enable-metrics'],text=True,capture_output=True,timeout=900,check=True)
        new=json.loads(proc.stdout)
        if group=='b': a.group_b.drop_rust_fns(new,cfg.get('rust_exclude_fns',set()))
        (dest/'new.stderr').write_text(proc.stderr)
    a.write(dest/'old.rust.json',old);a.write(dest/'new.rust.json',new)
    same=prior['functions']==new['functions'] and a.edges(prior)==a.edges(new)
    prior_pairs=row['variants']['new']['pairs']
    old_score=a.evaluate_pairs(row['variants']['old']['pairs'],old,truth)
    new_score=a.evaluate_pairs(prior_pairs,new,truth) if same else a.score(c,new,truth)
    row.update(variants={'old':old_score,'new':new_score},
               node_features_unchanged=old['functions']==new['functions'],
               consumed_graph_unchanged=old['functions']==new['functions'] and a.edges(old)==a.edges(new),
               removed_local_edges=sorted(a.edges(old)-a.edges(new)),
               added_local_edges=sorted(a.edges(new)-a.edges(old)),
               pairs_reused_from_v1_identical_inputs=same)
    a.write(dest/'comparison.json',row)
    return row

if __name__=='__main__':
    output=BASE/'final_audit';output.mkdir(exist_ok=False)
    refs={'a':BASE/'audit_a','b':BASE/'audit_b_fixed'}
    provenance={g:a.read(p/'provenance.json') for g,p in refs.items()}
    for p in provenance.values():
        assert p['old_binary_sha256']==a.digest(a.group_a.ANALYZER)
        assert p['matcher_sha256']==a.digest(a.ROOT/'tools/stu_selector/matcher.py')
        assert p['rustc']==subprocess.check_output(['rustc','--version'],text=True).strip()
    a.write(output/'provenance.json',dict(reference_runs=provenance,new_binary_sha256=a.digest(NEW),
                                        note='All artifacts re-extracted; cached matching reused only for identical consumed node/edge inputs.'))
    jobs=[(g,p.parent.name[3:],str(ref),str(output)) for g,ref in refs.items() for p in sorted(ref.glob('*/comparison.json'))]
    rows=[]
    with ProcessPoolExecutor(max_workers=2) as pool:
        for row in pool.map(run,jobs):
            rows.append(row)
            print(row['group'],row['case'],{k:(v['correct'],v['accepted'],len(v['unadjudicated'])) for k,v in row['variants'].items()},flush=True)
    summary={g:a.aggregate([r for r in rows if r['group']==g]) for g in ('a','b')}
    a.write(output/'summary.json',dict(rows=rows,aggregates=summary))
    print(json.dumps(summary,indent=2),flush=True)
